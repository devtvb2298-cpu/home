package site.kpeclub.ban.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import site.kpeclub.ban.BanManager;
import site.kpeclub.ban.IpBanEntry;
import site.kpeclub.ban.KPEBan;
import site.kpeclub.ban.util.BanScreen;
import site.kpeclub.ban.util.Completions;
import site.kpeclub.ban.util.IpUtil;
import site.kpeclub.ban.util.TimeUtil;

import java.net.InetSocketAddress;
import java.util.List;

/**
 * /banip <player|ip> [duration] [reason]
 * If given a raw IPv4 address, bans it directly. If given a player name, looks up
 * their most recently recorded IP (requires track-ips to have been on when they
 * last joined) and bans that. Blocks every account on that IP, not just one name —
 * this is what stops alts a name-only /ban can't catch.
 *
 * IP bans are never broadcast to public chat, even if broadcast-on-ban is on —
 * showing a player's IP address in server chat isn't something to do by default.
 */
public class BanIpCommand implements CommandExecutor, TabCompleter {

    private final KPEBan plugin;
    private final BanManager banManager;

    public BanIpCommand(KPEBan plugin, BanManager banManager) {
        this.plugin = plugin;
        this.banManager = banManager;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Completions.onlineNames(args[0]);
        }
        if (args.length == 2) {
            return Completions.durations(args[1]);
        }
        return List.of();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(Component.text("Usage: /banip <player|ip> [duration] [reason]", NamedTextColor.RED));
            return true;
        }

        String input = args[0];
        String ip = IpUtil.isIpAddress(input) ? input : banManager.getMostRecentIpByName(input);

        if (ip == null) {
            sender.sendMessage(Component.text(
                    "No known IP for " + input + " — they may not have joined yet, or track-ips is off.",
                    NamedTextColor.RED));
            return true;
        }

        long durationMillis = -1;
        int reasonStart = 1;

        if (args.length >= 2) {
            String maybeDuration = args[1];
            if (TimeUtil.isPermanentKeyword(maybeDuration)) {
                reasonStart = 2;
            } else {
                long parsed = TimeUtil.parseDuration(maybeDuration);
                if (parsed > 0) {
                    durationMillis = parsed;
                    reasonStart = 2;
                }
            }
        }

        String defaultReason = plugin.getConfig().getString("default-reason", "Cheating");
        String reason = defaultReason;
        if (args.length > reasonStart) {
            StringBuilder sb = new StringBuilder();
            for (int i = reasonStart; i < args.length; i++) {
                sb.append(args[i]).append(" ");
            }
            reason = sb.toString().trim();
        }

        String staffName = sender.getName();
        String finalIp = ip;
        String finalReason = reason;
        long finalDuration = durationMillis;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            int id = banManager.banIp(finalIp, finalReason, staffName, finalDuration);
            IpBanEntry entry = banManager.getActiveIpBan(finalIp);

            Bukkit.getScheduler().runTask(plugin, () -> {
                if (id == -1 || entry == null) {
                    sender.sendMessage(Component.text("Failed to ban IP " + finalIp + ".", NamedTextColor.RED));
                    return;
                }

                String appealLink = plugin.getConfig().getString("appeal-link", "");
                int kicked = 0;
                for (Player online : Bukkit.getOnlinePlayers()) {
                    InetSocketAddress addr = online.getAddress();
                    if (addr != null && addr.getAddress() != null
                            && finalIp.equals(addr.getAddress().getHostAddress())) {
                        online.kick(BanScreen.buildIp(entry, appealLink));
                        kicked++;
                    }
                }

                String durationText = finalDuration > 0
                        ? "for " + TimeUtil.formatRemaining(finalDuration)
                        : "permanently";
                sender.sendMessage(Component.text(
                        "Banned IP " + finalIp + " " + durationText + " (" + finalReason + ")"
                                + (kicked > 0 ? " — kicked " + kicked + " online player(s)" : ""),
                        NamedTextColor.GREEN));
            });
        });

        return true;
    }
}
