package site.kpeclub.ban.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import site.kpeclub.ban.BanEntry;
import site.kpeclub.ban.BanManager;

import java.util.List;

public class BanListCommand implements CommandExecutor {

    private final BanManager banManager;

    public BanListCommand(BanManager banManager) {
        this.banManager = banManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        List<BanEntry> bans = banManager.getActiveBans();

        if (bans.isEmpty()) {
            sender.sendMessage(Component.text("No active bans.", NamedTextColor.GRAY));
            return true;
        }

        sender.sendMessage(Component.text("Active bans (" + bans.size() + "):", NamedTextColor.GOLD));
        for (BanEntry ban : bans) {
            String duration = ban.isPermanent() ? "permanent" : "temporary";
            sender.sendMessage(Component.text(
                    " #" + ban.getId() + " " + ban.getPlayerName() + " — " + ban.getReason() + " (" + duration + ")",
                    NamedTextColor.GRAY));
        }
        return true;
    }
}
