package site.kpeclub.ban;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.LoggerConfig;
import org.bukkit.plugin.java.JavaPlugin;
import site.kpeclub.ban.commands.AltCheckCommand;
import site.kpeclub.ban.commands.AutoPunishCommand;
import site.kpeclub.ban.commands.BanCommand;
import site.kpeclub.ban.commands.BanHistoryCommand;
import site.kpeclub.ban.commands.BanInfoCommand;
import site.kpeclub.ban.commands.BanIpCommand;
import site.kpeclub.ban.commands.BanListCommand;
import site.kpeclub.ban.commands.ReloadCommand;
import site.kpeclub.ban.commands.UnbanCommand;
import site.kpeclub.ban.commands.UnbanIpCommand;
import site.kpeclub.ban.listeners.LoginListener;
import site.kpeclub.ban.util.ConsoleLogFilter;

import java.io.File;

public final class KPEBan extends JavaPlugin {

    private BanManager banManager;
    private PunishmentConfig punishmentConfig;
    private ConsoleLogFilter banConsoleFilter;
    private ConsoleLogFilter ipBanConsoleFilter;
    private ConsoleLogFilter uuidConsoleFilter;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        File dbFile = new File(getDataFolder(), "bans.db");
        this.banManager = new BanManager(dbFile);
        banManager.init();

        this.punishmentConfig = new PunishmentConfig(this);
        punishmentConfig.load();

        getCommand("ban").setExecutor(new BanCommand(this, banManager));
        getCommand("unban").setExecutor(new UnbanCommand(banManager));
        getCommand("baninfo").setExecutor(new BanInfoCommand(banManager));
        getCommand("banlist").setExecutor(new BanListCommand(banManager));
        getCommand("banhistory").setExecutor(new BanHistoryCommand(banManager));
        getCommand("banip").setExecutor(new BanIpCommand(this, banManager));
        getCommand("unbanip").setExecutor(new UnbanIpCommand(banManager));
        getCommand("altcheck").setExecutor(new AltCheckCommand(banManager));
        getCommand("kpebanauto").setExecutor(new AutoPunishCommand(this, banManager, punishmentConfig));
        getCommand("kpebanreload").setExecutor(new ReloadCommand(punishmentConfig));

        getServer().getPluginManager().registerEvents(new LoginListener(banManager, this), this);

        setupConsoleFilters();

        getLogger().info("KPE-Ban enabled.");
    }

    @Override
    public void onDisable() {
        teardownConsoleFilters();
        if (banManager != null) {
            banManager.close();
        }
    }

    public BanManager getBanManager() {
        return banManager;
    }

    /** Registers console log filters per config.yml, so they can be toggled without touching code. */
    private void setupConsoleFilters() {
        LoggerContext context = (LoggerContext) LogManager.getContext(false);
        Configuration config = context.getConfiguration();
        LoggerConfig rootConfig = config.getRootLogger();

        if (getConfig().getBoolean("hide-ban-console-log", true)) {
            banConsoleFilter = new ConsoleLogFilter("YOU ARE BANNED");
            rootConfig.addFilter(banConsoleFilter);
            ipBanConsoleFilter = new ConsoleLogFilter("YOUR IP IS BANNED");
            rootConfig.addFilter(ipBanConsoleFilter);
        }
        if (getConfig().getBoolean("hide-uuid-resolve-log", false)) {
            uuidConsoleFilter = new ConsoleLogFilter("UUID of player ");
            rootConfig.addFilter(uuidConsoleFilter);
        }
        context.updateLoggers();
    }

    private void teardownConsoleFilters() {
        LoggerContext context = (LoggerContext) LogManager.getContext(false);
        Configuration config = context.getConfiguration();
        LoggerConfig rootConfig = config.getRootLogger();

        if (banConsoleFilter != null) rootConfig.removeFilter(banConsoleFilter);
        if (ipBanConsoleFilter != null) rootConfig.removeFilter(ipBanConsoleFilter);
        if (uuidConsoleFilter != null) rootConfig.removeFilter(uuidConsoleFilter);
        context.updateLoggers();
    }
}
