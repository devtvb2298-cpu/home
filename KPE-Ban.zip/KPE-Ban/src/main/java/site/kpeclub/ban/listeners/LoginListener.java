package site.kpeclub.ban.listeners;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import site.kpeclub.ban.BanEntry;
import site.kpeclub.ban.BanManager;
import site.kpeclub.ban.IpBanEntry;
import site.kpeclub.ban.KPEBan;
import site.kpeclub.ban.util.BanScreen;

import java.net.InetAddress;

public class LoginListener implements Listener {

    private final BanManager banManager;
    private final KPEBan plugin;

    public LoginListener(BanManager banManager, KPEBan plugin) {
        this.banManager = banManager;
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPreLogin(AsyncPlayerPreLoginEvent event) {
        String uuid = event.getUniqueId().toString();
        String name = event.getName();
        InetAddress address = event.getAddress();
        String ip = address != null ? address.getHostAddress() : null;

        // Only collects new data when enabled — existing IP bans still enforce either way.
        if (ip != null && plugin.getConfig().getBoolean("track-ips", true)) {
            banManager.recordIp(uuid, name, ip);
        }

        String appealLink = plugin.getConfig().getString("appeal-link", "");

        // Name-based check: works the same for cracked and premium accounts, since the
        // login name is known immediately and doesn't depend on which uuid an auth
        // plugin (FastLogin etc.) ends up assigning, or on that resolution happening
        // before this listener runs.
        BanEntry ban = banManager.getActiveBanByName(name);

        // Fallback for older records saved before this check, keyed only by uuid.
        if (ban == null) {
            ban = banManager.getActiveBan(uuid);
        }
        if (ban != null) {
            event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_BANNED, BanScreen.build(ban, appealLink));
            return;
        }

        if (ip != null) {
            IpBanEntry ipBan = banManager.getActiveIpBan(ip);
            if (ipBan != null) {
                event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_BANNED, BanScreen.buildIp(ipBan, appealLink));
            }
        }
    }
}
