package site.kpeclub.ban.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import site.kpeclub.ban.AltAccount;
import site.kpeclub.ban.BanManager;
import site.kpeclub.ban.util.Completions;

import java.util.List;

public class AltCheckCommand implements CommandExecutor, TabCompleter {

    private final BanManager banManager;

    public AltCheckCommand(BanManager banManager) {
        this.banManager = banManager;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Completions.knownNames(banManager, args[0]);
        }
        return List.of();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(Component.text("Usage: /altcheck <player>", NamedTextColor.RED));
            return true;
        }

        String targetName = args[0];
        List<AltAccount> alts = banManager.findAltsForPlayerName(targetName);

        if (alts.isEmpty()) {
            sender.sendMessage(Component.text(
                    "No known alts for " + targetName + " (or track-ips is off / they haven't joined).",
                    NamedTextColor.GRAY));
            return true;
        }

        sender.sendMessage(Component.text("Accounts sharing an IP with " + targetName + ":", NamedTextColor.GOLD));
        for (AltAccount alt : alts) {
            sender.sendMessage(Component.text(" - " + alt.playerName(), NamedTextColor.WHITE));
        }
        return true;
    }
}
