package site.kpeclub.ban.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import site.kpeclub.ban.BanEntry;
import site.kpeclub.ban.IpBanEntry;

import java.text.SimpleDateFormat;
import java.util.Date;

public class BanScreen {

    public static Component build(BanEntry ban, String appealLink) {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm");

        Component screen = Component.text("YOU ARE BANNED", NamedTextColor.RED, TextDecoration.BOLD)
                .append(Component.newline()).append(Component.newline())
                .append(line("Reason", ban.getReason()))
                .append(Component.newline())
                .append(line("Banned by", ban.getBannedBy()))
                .append(Component.newline())
                .append(line("Ban ID", "#" + ban.getId()))
                .append(Component.newline())
                .append(line("Date", fmt.format(new Date(ban.getBannedAt()))))
                .append(Component.newline()).append(Component.newline());

        screen = appendExpiry(screen, ban.isPermanent(), ban.getExpiresAt(), fmt);
        screen = appendAppeal(screen, appealLink);
        return screen;
    }

    /** Same shape, for a ban tied to an IP address rather than a specific account. */
    public static Component buildIp(IpBanEntry ban, String appealLink) {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm");

        Component screen = Component.text("YOUR IP IS BANNED", NamedTextColor.RED, TextDecoration.BOLD)
                .append(Component.newline()).append(Component.newline())
                .append(line("Reason", ban.getReason()))
                .append(Component.newline())
                .append(line("Banned by", ban.getBannedBy()))
                .append(Component.newline())
                .append(line("Ban ID", "#IP" + ban.getId()))
                .append(Component.newline())
                .append(line("Date", fmt.format(new Date(ban.getBannedAt()))))
                .append(Component.newline()).append(Component.newline());

        screen = appendExpiry(screen, ban.isPermanent(), ban.getExpiresAt(), fmt);
        screen = appendAppeal(screen, appealLink);
        return screen;
    }

    private static Component appendExpiry(Component screen, boolean permanent, Long expiresAt, SimpleDateFormat fmt) {
        if (permanent) {
            return screen.append(Component.text("This ban is permanent.", NamedTextColor.GRAY));
        }
        long remaining = expiresAt - System.currentTimeMillis();
        return screen
                .append(Component.text("Time remaining: ", NamedTextColor.GRAY)
                        .append(Component.text(TimeUtil.formatRemaining(remaining), NamedTextColor.GOLD)))
                .append(Component.newline())
                .append(Component.text("Expires: " + fmt.format(new Date(expiresAt)), NamedTextColor.DARK_GRAY));
    }

    private static Component appendAppeal(Component screen, String appealLink) {
        if (appealLink == null || appealLink.isBlank()) return screen;
        return screen.append(Component.newline()).append(Component.newline())
                .append(Component.text("Appeal at: ", NamedTextColor.GRAY)
                        .append(Component.text(appealLink, NamedTextColor.AQUA)));
    }

    private static Component line(String label, String value) {
        return Component.text(label + ": ", NamedTextColor.GRAY)
                .append(Component.text(value, NamedTextColor.WHITE));
    }
}

