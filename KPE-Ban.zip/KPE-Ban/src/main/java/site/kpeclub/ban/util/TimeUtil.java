package site.kpeclub.ban.util;

public class TimeUtil {

    /** Parses strings like 30s, 10m, 6h, 7d, 2w. Returns millis, or -1 if not a valid duration. */
    public static long parseDuration(String input) {
        if (input == null || input.length() < 2) return -1;
        String s = input.toLowerCase();
        try {
            char unit = s.charAt(s.length() - 1);
            long amount = Long.parseLong(s.substring(0, s.length() - 1));
            long unitMillis = switch (unit) {
                case 's' -> 1000L;
                case 'm' -> 60_000L;
                case 'h' -> 3_600_000L;
                case 'd' -> 86_400_000L;
                case 'w' -> 604_800_000L;
                default -> -1L;
            };
            if (unitMillis == -1L || amount <= 0) return -1;
            return amount * unitMillis;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public static boolean isPermanentKeyword(String s) {
        return s.equalsIgnoreCase("perm") || s.equalsIgnoreCase("permanent");
    }

    /** Formats remaining millis as "6d 23h 12m 45s". */
    public static String formatRemaining(long millis) {
        if (millis <= 0) return "0s";
        long days = millis / 86_400_000L;
        millis %= 86_400_000L;
        long hours = millis / 3_600_000L;
        millis %= 3_600_000L;
        long minutes = millis / 60_000L;
        millis %= 60_000L;
        long seconds = millis / 1000L;

        StringBuilder sb = new StringBuilder();
        if (days > 0) sb.append(days).append("d ");
        if (days > 0 || hours > 0) sb.append(hours).append("h ");
        if (days > 0 || hours > 0 || minutes > 0) sb.append(minutes).append("m ");
        sb.append(seconds).append("s");
        return sb.toString().trim();
    }
}
