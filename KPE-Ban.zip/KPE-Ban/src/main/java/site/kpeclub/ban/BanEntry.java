package site.kpeclub.ban;

public class BanEntry {

    private final int id;
    private final String uuid;
    private final String playerName;
    private final String reason;
    private final String bannedBy;
    private final long bannedAt;
    private final Long expiresAt; // null = permanent
    private final boolean active; // raw DB flag: false once lifted (manually or by expiry cleanup)

    public BanEntry(int id, String uuid, String playerName, String reason,
                     String bannedBy, long bannedAt, Long expiresAt, boolean active) {
        this.id = id;
        this.uuid = uuid;
        this.playerName = playerName;
        this.reason = reason;
        this.bannedBy = bannedBy;
        this.bannedAt = bannedAt;
        this.expiresAt = expiresAt;
        this.active = active;
    }

    public int getId() { return id; }
    public String getUuid() { return uuid; }
    public String getPlayerName() { return playerName; }
    public String getReason() { return reason; }
    public String getBannedBy() { return bannedBy; }
    public long getBannedAt() { return bannedAt; }
    public Long getExpiresAt() { return expiresAt; }
    public boolean isActive() { return active; }

    public boolean isPermanent() {
        return expiresAt == null;
    }

    public boolean isExpired() {
        return expiresAt != null && System.currentTimeMillis() >= expiresAt;
    }
}
