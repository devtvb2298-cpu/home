package site.kpeclub.ban.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import site.kpeclub.ban.PunishmentConfig;

public class ReloadCommand implements CommandExecutor {

    private final PunishmentConfig punishmentConfig;

    public ReloadCommand(PunishmentConfig punishmentConfig) {
        this.punishmentConfig = punishmentConfig;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        punishmentConfig.load();
        String status = punishmentConfig.isEnabled() ? "enabled" : "disabled";
        sender.sendMessage(Component.text(
                "KPE-Ban: punishments.yml reloaded (auto-punish " + status + ").", NamedTextColor.GREEN));
        return true;
    }
}
