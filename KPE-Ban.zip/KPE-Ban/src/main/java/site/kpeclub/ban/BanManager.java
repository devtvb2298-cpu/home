package site.kpeclub.ban;

import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BanManager {

    private final File dbFile;
    private Connection connection;

    public BanManager(File dbFile) {
        this.dbFile = dbFile;
    }

    public void init() {
        try {
            dbFile.getParentFile().mkdirs();
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());
            try (Statement st = connection.createStatement()) {
                st.execute("""
                    CREATE TABLE IF NOT EXISTS bans (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        uuid TEXT NOT NULL,
                        player_name TEXT NOT NULL,
                        reason TEXT NOT NULL,
                        banned_by TEXT NOT NULL,
                        banned_at INTEGER NOT NULL,
                        expires_at INTEGER,
                        active INTEGER NOT NULL DEFAULT 1
                    )
                    """);
                st.execute("CREATE INDEX IF NOT EXISTS idx_bans_uuid ON bans(uuid)");
                st.execute("CREATE INDEX IF NOT EXISTS idx_bans_name ON bans(player_name)");

                st.execute("""
                    CREATE TABLE IF NOT EXISTS ip_bans (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        ip TEXT NOT NULL,
                        reason TEXT NOT NULL,
                        banned_by TEXT NOT NULL,
                        banned_at INTEGER NOT NULL,
                        expires_at INTEGER,
                        active INTEGER NOT NULL DEFAULT 1
                    )
                    """);
                st.execute("CREATE INDEX IF NOT EXISTS idx_ip_bans_ip ON ip_bans(ip)");

                st.execute("""
                    CREATE TABLE IF NOT EXISTS player_ips (
                        uuid TEXT NOT NULL,
                        player_name TEXT NOT NULL,
                        ip TEXT NOT NULL,
                        last_seen INTEGER NOT NULL,
                        PRIMARY KEY (uuid, ip)
                    )
                    """);
                st.execute("CREATE INDEX IF NOT EXISTS idx_player_ips_ip ON player_ips(ip)");
                st.execute("CREATE INDEX IF NOT EXISTS idx_player_ips_uuid ON player_ips(uuid)");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void close() {
        try {
            if (connection != null) connection.close();
        } catch (SQLException ignored) {
        }
    }

    /** Bans a player. durationMillis <= 0 means permanent. Returns the new ban's id, or -1 on failure. */
    public synchronized int ban(String uuid, String playerName, String reason, String bannedBy, long durationMillis) {
        unban(uuid);            // clear any previous active ban by uuid
        unbanByName(playerName); // and by name, in case uuid differs (cracked vs premium)

        String sql = "INSERT INTO bans (uuid, player_name, reason, banned_by, banned_at, expires_at, active) VALUES (?,?,?,?,?,?,1)";
        try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            long now = System.currentTimeMillis();
            ps.setString(1, uuid);
            ps.setString(2, playerName);
            ps.setString(3, reason);
            ps.setString(4, bannedBy);
            ps.setLong(5, now);
            if (durationMillis > 0) {
                ps.setLong(6, now + durationMillis);
            } else {
                ps.setNull(6, Types.BIGINT);
            }
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    /** Deactivates the active ban for this uuid, if any. Returns true if a ban was removed. */
    public synchronized boolean unban(String uuid) {
        String sql = "UPDATE bans SET active = 0 WHERE uuid = ? AND active = 1";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, uuid);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Deactivates the active ban for this player name (case-insensitive), if any.
     * Fallback for when the uuid computed from a typed name doesn't match the uuid
     * stored at ban time (e.g. staff typed the name with different case).
     */
    public synchronized boolean unbanByName(String name) {
        String sql = "UPDATE bans SET active = 0 WHERE active = 1 AND LOWER(player_name) = LOWER(?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, name);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /** Returns the active ban for this uuid, or null if not banned. Expired bans are auto-cleared. */
    public synchronized BanEntry getActiveBan(String uuid) {
        String sql = "SELECT * FROM bans WHERE uuid = ? AND active = 1 ORDER BY id DESC LIMIT 1";
        BanEntry entry = null;
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, uuid);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) entry = fromRow(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

        if (entry == null) return null;
        if (entry.isExpired()) {
            unban(uuid); // safe now — the read statement/cursor above is already closed
            return null;
        }
        return entry;
    }

    /**
     * Returns the active ban for this player name (case-insensitive), or null if not banned.
     * This is the reliable check for login enforcement: name is known the same way for both
     * cracked and premium accounts, so it isn't affected by which uuid an auth plugin ends
     * up assigning. Expired bans are auto-cleared.
     */
    public synchronized BanEntry getActiveBanByName(String name) {
        String sql = "SELECT * FROM bans WHERE active = 1 AND LOWER(player_name) = LOWER(?) ORDER BY id DESC LIMIT 1";
        BanEntry entry = null;
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) entry = fromRow(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

        if (entry == null) return null;
        if (entry.isExpired()) {
            unbanByName(name); // safe now — the read statement/cursor above is already closed
            return null;
        }
        return entry;
    }

    public synchronized List<BanEntry> getActiveBans() {
        List<BanEntry> list = new ArrayList<>();
        List<String> expiredUuids = new ArrayList<>();
        String sql = "SELECT * FROM bans WHERE active = 1 ORDER BY id DESC";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                BanEntry entry = fromRow(rs);
                if (!entry.isExpired()) {
                    list.add(entry);
                } else {
                    expiredUuids.add(entry.getUuid());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        for (String uuid : expiredUuids) {
            unban(uuid); // safe now — the read cursor above is already closed
        }
        return list;
    }

    private BanEntry fromRow(ResultSet rs) throws SQLException {
        long expiresAt = rs.getLong("expires_at");
        Long expires = rs.wasNull() ? null : expiresAt;
        return new BanEntry(
                rs.getInt("id"),
                rs.getString("uuid"),
                rs.getString("player_name"),
                rs.getString("reason"),
                rs.getString("banned_by"),
                rs.getLong("banned_at"),
                expires,
                rs.getInt("active") == 1
        );
    }

    /** Every ban ever recorded for this player name (case-insensitive), newest first — active, expired, and lifted alike. */
    public synchronized List<BanEntry> getBanHistory(String name) {
        List<BanEntry> list = new ArrayList<>();
        String sql = "SELECT * FROM bans WHERE LOWER(player_name) = LOWER(?) ORDER BY id DESC";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(fromRow(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // ---------------------------------------------------------------------
    // IP tracking (for /banip and alt detection)
    // ---------------------------------------------------------------------

    /** Records that this uuid/name connected from this IP, so /banip and alt lookups have data to work with. */
    public synchronized void recordIp(String uuid, String playerName, String ip) {
        String sql = """
            INSERT INTO player_ips (uuid, player_name, ip, last_seen) VALUES (?,?,?,?)
            ON CONFLICT(uuid, ip) DO UPDATE SET player_name = excluded.player_name, last_seen = excluded.last_seen
            """;
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, uuid);
            ps.setString(2, playerName);
            ps.setString(3, ip);
            ps.setLong(4, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /** This player's most recently seen IP, or null if none recorded (e.g. track-ips was off, or they've never joined). */
    public synchronized String getMostRecentIp(String uuid) {
        String sql = "SELECT ip FROM player_ips WHERE uuid = ? ORDER BY last_seen DESC LIMIT 1";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, uuid);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getString("ip");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /** Same as {@link #getMostRecentIp(String)}, but looked up by name (case-insensitive) instead of uuid. */
    public synchronized String getMostRecentIpByName(String name) {
        String sql = "SELECT ip FROM player_ips WHERE LOWER(player_name) = LOWER(?) ORDER BY last_seen DESC LIMIT 1";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getString("ip");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /** Other accounts (distinct uuid+name) that have shared any IP with this uuid, this player excluded. */
    public synchronized List<AltAccount> findAltsForPlayer(String uuid) {
        List<AltAccount> alts = new ArrayList<>();
        String sql = """
            SELECT DISTINCT p2.uuid AS alt_uuid, p2.player_name AS alt_name
            FROM player_ips p1
            JOIN player_ips p2 ON p2.ip = p1.ip AND p2.uuid != p1.uuid
            WHERE p1.uuid = ?
            """;
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, uuid);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    alts.add(new AltAccount(rs.getString("alt_uuid"), rs.getString("alt_name")));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return alts;
    }

    /** Same as {@link #findAltsForPlayer(String)}, but looked up by name (case-insensitive) instead of uuid. */
    public synchronized List<AltAccount> findAltsForPlayerName(String name) {
        String uuid = null;
        String sql = "SELECT uuid FROM player_ips WHERE LOWER(player_name) = LOWER(?) LIMIT 1";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) uuid = rs.getString("uuid");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
        return uuid != null ? findAltsForPlayer(uuid) : new ArrayList<>();
    }

    // ---------------------------------------------------------------------
    // IP bans
    // ---------------------------------------------------------------------

    /** Bans an IP address directly. durationMillis <= 0 means permanent. Returns the new ban's id, or -1 on failure. */
    public synchronized int banIp(String ip, String reason, String bannedBy, long durationMillis) {
        unbanIp(ip); // clear any previous active ban for this ip first

        String sql = "INSERT INTO ip_bans (ip, reason, banned_by, banned_at, expires_at, active) VALUES (?,?,?,?,?,1)";
        try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            long now = System.currentTimeMillis();
            ps.setString(1, ip);
            ps.setString(2, reason);
            ps.setString(3, bannedBy);
            ps.setLong(4, now);
            if (durationMillis > 0) {
                ps.setLong(5, now + durationMillis);
            } else {
                ps.setNull(5, Types.BIGINT);
            }
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public synchronized boolean unbanIp(String ip) {
        String sql = "UPDATE ip_bans SET active = 0 WHERE ip = ? AND active = 1";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, ip);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /** Returns the active ban for this IP, or null if not banned. Expired bans are auto-cleared. */
    public synchronized IpBanEntry getActiveIpBan(String ip) {
        String sql = "SELECT * FROM ip_bans WHERE ip = ? AND active = 1 ORDER BY id DESC LIMIT 1";
        IpBanEntry entry = null;
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, ip);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) entry = fromIpRow(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

        if (entry == null) return null;
        if (entry.isExpired()) {
            unbanIp(ip); // safe now — the read statement/cursor above is already closed
            return null;
        }
        return entry;
    }

    public synchronized List<IpBanEntry> getActiveIpBans() {
        List<IpBanEntry> list = new ArrayList<>();
        List<String> expiredIps = new ArrayList<>();
        String sql = "SELECT * FROM ip_bans WHERE active = 1 ORDER BY id DESC";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                IpBanEntry entry = fromIpRow(rs);
                if (!entry.isExpired()) {
                    list.add(entry);
                } else {
                    expiredIps.add(entry.getIp());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        for (String ip : expiredIps) {
            unbanIp(ip); // safe now — the read cursor above is already closed
        }
        return list;
    }

    private IpBanEntry fromIpRow(ResultSet rs) throws SQLException {
        long expiresAt = rs.getLong("expires_at");
        Long expires = rs.wasNull() ? null : expiresAt;
        return new IpBanEntry(
                rs.getInt("id"),
                rs.getString("ip"),
                rs.getString("reason"),
                rs.getString("banned_by"),
                rs.getLong("banned_at"),
                expires
        );
    }
}
