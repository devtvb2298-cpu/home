package site.kpeclub.ban.util;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import site.kpeclub.ban.BanEntry;
import site.kpeclub.ban.BanManager;
import site.kpeclub.ban.IpBanEntry;

import java.util.ArrayList;
import java.util.List;

public class Completions {

    public static final List<String> DURATIONS =
            List.of("30s", "10m", "1h", "6h", "12h", "1d", "7d", "30d", "perm");

    /** Online player names starting with prefix (case-insensitive). */
    public static List<String> onlineNames(String prefix) {
        String lower = prefix.toLowerCase();
        List<String> out = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getName().toLowerCase().startsWith(lower)) out.add(p.getName());
        }
        return out;
    }

    /** Names of players with an active ban, starting with prefix — what you'd want for /unban. */
    public static List<String> bannedNames(BanManager banManager, String prefix) {
        String lower = prefix.toLowerCase();
        List<String> out = new ArrayList<>();
        for (BanEntry entry : banManager.getActiveBans()) {
            if (entry.getPlayerName().toLowerCase().startsWith(lower)) out.add(entry.getPlayerName());
        }
        return out;
    }

    /** Currently banned IPs starting with prefix — for /unbanip. */
    public static List<String> bannedIps(BanManager banManager, String prefix) {
        List<String> out = new ArrayList<>();
        for (IpBanEntry entry : banManager.getActiveIpBans()) {
            if (entry.getIp().startsWith(prefix)) out.add(entry.getIp());
        }
        return out;
    }

    /** Union of online names and currently-banned names, deduplicated — for lookup commands like /baninfo. */
    public static List<String> knownNames(BanManager banManager, String prefix) {
        List<String> out = new ArrayList<>(onlineNames(prefix));
        for (String name : bannedNames(banManager, prefix)) {
            if (!out.contains(name)) out.add(name);
        }
        return out;
    }

    public static List<String> durations(String prefix) {
        List<String> out = new ArrayList<>();
        for (String d : DURATIONS) {
            if (d.startsWith(prefix)) out.add(d);
        }
        return out;
    }
}
