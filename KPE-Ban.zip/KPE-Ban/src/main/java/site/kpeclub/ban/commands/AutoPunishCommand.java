package site.kpeclub.ban.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import site.kpeclub.ban.BanEntry;
import site.kpeclub.ban.BanManager;
import site.kpeclub.ban.KPEBan;
import site.kpeclub.ban.PunishmentConfig;
import site.kpeclub.ban.util.BanScreen;
import site.kpeclub.ban.util.TimeUtil;

/**
 * kpebanauto <player> <check>
 * Not meant to be run manually — this is the bridge target for an anticheat's own
 * punishment system (GrimAC's punishments.yml, Vulcan's per-check commands) to call
 * once a check crosses ITS OWN violation threshold. Looks the check name up in
 * KPE-Ban's punishments.yml and applies the matching ban through the normal ban
 * system (same kick screen, storage, broadcast as /ban).
 */
public class AutoPunishCommand implements CommandExecutor {

    private final KPEBan plugin;
    private final BanManager banManager;
    private final PunishmentConfig punishmentConfig;

    public AutoPunishCommand(KPEBan plugin, BanManager banManager, PunishmentConfig punishmentConfig) {
        this.plugin = plugin;
        this.banManager = banManager;
        this.punishmentConfig = punishmentConfig;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(Component.text("Usage: kpebanauto <player> [check]", NamedTextColor.RED));
            return true;
        }

        String targetName = args[0];
        String checkName = args.length >= 2 ? args[1] : "unknown";

        if (!punishmentConfig.isEnabled()) {
            plugin.getLogger().info("kpebanauto: auto-punish is disabled in punishments.yml, ignoring "
                    + checkName + " for " + targetName + ".");
            return true;
        }

        PunishmentConfig.Rule rule = punishmentConfig.findRule(checkName);
        if (rule == null) {
            plugin.getLogger().info("kpebanauto: no punishments.yml rule matched check '"
                    + checkName + "' for " + targetName + " — ignoring.");
            return true;
        }
        if (!rule.enabled()) {
            plugin.getLogger().info("kpebanauto: rule for check '" + checkName
                    + "' is disabled in punishments.yml, ignoring (" + targetName + ").");
            return true;
        }

        long durationMillis;
        if (TimeUtil.isPermanentKeyword(rule.duration())) {
            durationMillis = -1;
        } else {
            long parsed = TimeUtil.parseDuration(rule.duration());
            durationMillis = parsed > 0 ? parsed : -1; // bad config value -> fall back to permanent
        }

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
            String uuid = target.getUniqueId().toString();
            String resolvedName = target.getName() != null ? target.getName() : targetName;

            int id = banManager.ban(uuid, resolvedName, rule.reason(), "AutoPunish", durationMillis);
            BanEntry entry = banManager.getActiveBan(uuid);

            Bukkit.getScheduler().runTask(plugin, () -> {
                if (id == -1 || entry == null) return;

                Player online = Bukkit.getPlayerExact(targetName);
                if (online != null) {
                    String appealLink = plugin.getConfig().getString("appeal-link", "");
                    online.kick(BanScreen.build(entry, appealLink));
                }

                plugin.getLogger().info("Auto-banned " + resolvedName + " for " + rule.reason()
                        + " (check: " + checkName + ")");

                if (plugin.getConfig().getBoolean("broadcast-on-ban", true)) {
                    Bukkit.broadcast(Component.text("⚠ ", NamedTextColor.RED)
                            .append(Component.text(resolvedName, NamedTextColor.WHITE))
                            .append(Component.text(" was banned for ", NamedTextColor.GRAY))
                            .append(Component.text(rule.reason(), NamedTextColor.RED)));
                }
            });
        });

        return true;
    }
}
