package site.kpeclub.ban.util;

import java.util.UUID;
import java.util.regex.Pattern;

public class UuidUtil {

    private static final Pattern DASHED = Pattern.compile(
            "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$");
    private static final Pattern UNDASHED = Pattern.compile("^[0-9a-fA-F]{32}$");

    /**
     * Parses a UUID given in either dashed (8-4-4-4-12) or undashed (32 hex chars,
     * e.g. copied straight from some APIs) form. Returns null if the input isn't a
     * valid UUID — callers use that to fall back to treating it as a player name.
     */
    public static UUID parse(String input) {
        if (input == null) return null;

        if (DASHED.matcher(input).matches()) {
            return safeParse(input);
        }
        if (UNDASHED.matcher(input).matches()) {
            String dashed = input.replaceFirst(
                    "([0-9a-fA-F]{8})([0-9a-fA-F]{4})([0-9a-fA-F]{4})([0-9a-fA-F]{4})([0-9a-fA-F]{12})",
                    "$1-$2-$3-$4-$5");
            return safeParse(dashed);
        }
        return null;
    }

    private static UUID safeParse(String dashed) {
        try {
            return UUID.fromString(dashed);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
