package site.kpeclub.ban.util;

import java.util.regex.Pattern;

public class IpUtil {

    private static final Pattern IPV4 = Pattern.compile(
            "^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");

    /** True if the input looks like a raw IPv4 address (e.g. "175.100.46.145") rather than a player name. */
    public static boolean isIpAddress(String input) {
        return input != null && IPV4.matcher(input).matches();
    }
}
