package site.kpeclub.ban;

public class IpBanEntry {

    private final int id;
    private final String ip;
    private final String reason;
    private final String bannedBy;
    private final long bannedAt;
    private final Long expiresAt; // null = permanent

    public IpBanEntry(int id, String ip, String reason, String bannedBy, long bannedAt, Long expiresAt) {
        this.id = id;
        this.ip = ip;
        this.reason = reason;
        this.bannedBy = bannedBy;
        this.bannedAt = bannedAt;
        this.expiresAt = expiresAt;
    }

    public int getId() { return id; }
    public String getIp() { return ip; }
    public String getReason() { return reason; }
    public String getBannedBy() { return bannedBy; }
    public long getBannedAt() { return bannedAt; }
    public Long getExpiresAt() { return expiresAt; }

    public boolean isPermanent() {
        return expiresAt == null;
    }

    public boolean isExpired() {
        return expiresAt != null && System.currentTimeMillis() >= expiresAt;
    }
}
