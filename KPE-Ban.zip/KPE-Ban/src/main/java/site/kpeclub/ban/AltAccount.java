package site.kpeclub.ban;

/** One other account that has connected from the same IP as a looked-up player. */
public record AltAccount(String uuid, String playerName) {
}
