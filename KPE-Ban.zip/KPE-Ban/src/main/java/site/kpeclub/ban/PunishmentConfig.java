package site.kpeclub.ban;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Loads punishments.yml — the rules used when an anticheat (GrimAC, Vulcan, etc.)
 * calls the kpebanauto bridge command after a check crosses its own violation
 * threshold. Each rule maps a check name to a ban duration + reason; matching is
 * case-insensitive "contains", so a rule for "Hitbox" also matches "HitboxA" etc.
 */
public class PunishmentConfig {

    public record Rule(String reason, String duration, boolean enabled) {}

    private final JavaPlugin plugin;
    private final File file;
    private final Map<String, Rule> rules = new LinkedHashMap<>();
    private Rule defaultRule;
    private boolean enabled = true;

    public PunishmentConfig(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "punishments.yml");
    }

    /** Master switch from punishments.yml — false means kpebanauto should do nothing at all. */
    public boolean isEnabled() {
        return enabled;
    }

    /** (Re)loads punishments.yml from disk, copying the bundled default if it doesn't exist yet. */
    public void load() {
        if (!file.exists()) {
            plugin.saveResource("punishments.yml", false);
        }

        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        rules.clear();
        defaultRule = null;
        enabled = yaml.getBoolean("enabled", true);

        ConfigurationSection rulesSection = yaml.getConfigurationSection("rules");
        if (rulesSection != null) {
            for (String key : rulesSection.getKeys(false)) {
                ConfigurationSection rule = rulesSection.getConfigurationSection(key);
                if (rule == null) continue;
                rules.put(key, new Rule(
                        rule.getString("reason", "Cheating (" + key + ")"),
                        rule.getString("duration", "perm"),
                        rule.getBoolean("enabled", true)
                ));
            }
        }

        ConfigurationSection defaultSection = yaml.getConfigurationSection("default");
        if (defaultSection != null) {
            defaultRule = new Rule(
                    defaultSection.getString("reason", "Cheating (auto-detected)"),
                    defaultSection.getString("duration", "perm"),
                    defaultSection.getBoolean("enabled", true)
            );
        }
    }

    /**
     * Finds the rule for an incoming check name (e.g. "HitboxA"), matching case-insensitively
     * against configured rule keys as a "contains" check. Falls back to the default rule (if
     * configured), or null if nothing matches and there's no default.
     */
    public Rule findRule(String checkName) {
        if (checkName != null) {
            String lower = checkName.toLowerCase();
            for (Map.Entry<String, Rule> entry : rules.entrySet()) {
                if (lower.contains(entry.getKey().toLowerCase())) {
                    return entry.getValue();
                }
            }
        }
        return defaultRule;
    }
}
