package site.kpeclub.ban.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import site.kpeclub.ban.BanManager;
import site.kpeclub.ban.util.Completions;
import site.kpeclub.ban.util.UuidUtil;

import java.util.List;
import java.util.UUID;

public class UnbanCommand implements CommandExecutor, TabCompleter {

    private final BanManager banManager;

    public UnbanCommand(BanManager banManager) {
        this.banManager = banManager;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Completions.bannedNames(banManager, args[0]);
        }
        return List.of();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(Component.text("Usage: /unban <player|uuid>", NamedTextColor.RED));
            return true;
        }

        String targetName = args[0];
        UUID parsedUuid = UuidUtil.parse(targetName);

        boolean removed = parsedUuid != null
                ? banManager.unban(parsedUuid.toString())
                : banManager.unbanByName(targetName);

        if (removed) {
            sender.sendMessage(Component.text("Unbanned " + targetName + ".", NamedTextColor.GREEN));
        } else {
            sender.sendMessage(Component.text(targetName + " is not banned.", NamedTextColor.GRAY));
        }
        return true;
    }
}
