package site.kpeclub.ban.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import site.kpeclub.ban.BanEntry;
import site.kpeclub.ban.BanManager;
import site.kpeclub.ban.util.Completions;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class BanHistoryCommand implements CommandExecutor, TabCompleter {

    private final BanManager banManager;

    public BanHistoryCommand(BanManager banManager) {
        this.banManager = banManager;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Completions.knownNames(banManager, args[0]);
        }
        return List.of();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(Component.text("Usage: /banhistory <player>", NamedTextColor.RED));
            return true;
        }

        String targetName = args[0];
        List<BanEntry> history = banManager.getBanHistory(targetName);

        if (history.isEmpty()) {
            sender.sendMessage(Component.text(targetName + " has no ban history.", NamedTextColor.GRAY));
            return true;
        }

        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        sender.sendMessage(Component.text(
                "Ban history for " + targetName + " (" + history.size() + "):", NamedTextColor.GOLD));

        for (BanEntry entry : history) {
            String status;
            NamedTextColor statusColor;
            if (!entry.isActive()) {
                // expires_at survives being cleared, so this still tells expired apart from lifted.
                status = entry.isExpired() ? "expired" : "lifted";
                statusColor = NamedTextColor.GRAY;
            } else {
                status = "active";
                statusColor = NamedTextColor.RED;
            }

            sender.sendMessage(Component.text(" #" + entry.getId() + " ", NamedTextColor.WHITE)
                    .append(Component.text(entry.getReason(), NamedTextColor.GRAY))
                    .append(Component.text(" — by " + entry.getBannedBy()
                            + " on " + fmt.format(new Date(entry.getBannedAt())) + " [", NamedTextColor.DARK_GRAY))
                    .append(Component.text(status, statusColor))
                    .append(Component.text("]", NamedTextColor.DARK_GRAY)));
        }
        return true;
    }
}
