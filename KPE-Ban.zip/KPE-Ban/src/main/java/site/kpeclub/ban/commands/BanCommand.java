package site.kpeclub.ban.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import site.kpeclub.ban.AltAccount;
import site.kpeclub.ban.BanEntry;
import site.kpeclub.ban.BanManager;
import site.kpeclub.ban.KPEBan;
import site.kpeclub.ban.util.BanScreen;
import site.kpeclub.ban.util.Completions;
import site.kpeclub.ban.util.TimeUtil;
import site.kpeclub.ban.util.UuidUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * /ban <player|uuid> [duration] [reason] [-s|--silent]
 * The first argument may be a player name or a raw UUID (dashed or undashed) —
 * useful for banning someone pre-emptively from a UUID you already have on hand.
 * duration is optional (e.g. 7d, 12h, 30m, perm). Omit it for a permanent ban.
 * This is the "cooldown ban": with a duration, the player is locked out until
 * it expires, and the ban screen shows a live countdown.
 * -s / --silent (anywhere in the args) skips the public chat broadcast.
 */
public class BanCommand implements CommandExecutor, TabCompleter {

    private final KPEBan plugin;
    private final BanManager banManager;

    public BanCommand(KPEBan plugin, BanManager banManager) {
        this.plugin = plugin;
        this.banManager = banManager;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Completions.onlineNames(args[0]);
        }
        if (args.length == 2) {
            String prefix = args[1].toLowerCase();
            List<String> out = new ArrayList<>(Completions.durations(args[1]));
            if ("-s".startsWith(prefix)) out.add("-s");
            if ("--silent".startsWith(prefix)) out.add("--silent");
            return out;
        }
        return List.of();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(Component.text(
                    "Usage: /ban <player|uuid> [duration] [reason] [-s]", NamedTextColor.RED));
            return true;
        }

        String targetName = args[0];
        UUID parsedUuid = UuidUtil.parse(targetName);

        boolean silent = false;
        List<String> rest = new ArrayList<>();
        for (int i = 1; i < args.length; i++) {
            if (args[i].equalsIgnoreCase("-s") || args[i].equalsIgnoreCase("--silent")) {
                silent = true;
            } else {
                rest.add(args[i]);
            }
        }

        long durationMillis = -1;
        int reasonStart = 0;

        if (!rest.isEmpty()) {
            String maybeDuration = rest.get(0);
            if (TimeUtil.isPermanentKeyword(maybeDuration)) {
                reasonStart = 1;
            } else {
                long parsed = TimeUtil.parseDuration(maybeDuration);
                if (parsed > 0) {
                    durationMillis = parsed;
                    reasonStart = 1;
                }
            }
        }

        String defaultReason = plugin.getConfig().getString("default-reason", "Cheating");
        String reason = defaultReason;
        if (rest.size() > reasonStart) {
            reason = String.join(" ", rest.subList(reasonStart, rest.size()));
        }

        String staffName = sender.getName();
        String finalReason = reason;
        long finalDuration = durationMillis;
        boolean finalSilent = silent;

        // OfflinePlayer lookup + DB write off the main thread: Bukkit.getOfflinePlayer(String)
        // can block on a web request for a name that's never joined before, so it must not
        // run on the main thread. Only Bukkit calls that need the main thread happen in the
        // runTask() below.
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            String uuid;
            String resolvedName;

            if (parsedUuid != null) {
                // Bukkit.getOfflinePlayer(UUID) is a local lookup only, never blocking.
                OfflinePlayer target = Bukkit.getOfflinePlayer(parsedUuid);
                uuid = parsedUuid.toString();
                resolvedName = target.getName() != null ? target.getName() : uuid;
            } else {
                OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
                uuid = target.getUniqueId().toString();
                resolvedName = target.getName() != null ? target.getName() : targetName;
            }

            int id = banManager.ban(uuid, resolvedName, finalReason, staffName, finalDuration);
            BanEntry entry = banManager.getActiveBan(uuid);
            String finalResolvedName = resolvedName;

            List<AltAccount> alts = plugin.getConfig().getBoolean("show-alts-on-ban", true)
                    ? banManager.findAltsForPlayer(uuid)
                    : List.of();

            Bukkit.getScheduler().runTask(plugin, () -> {
                if (id == -1 || entry == null) {
                    sender.sendMessage(Component.text("Failed to ban " + targetName + ".", NamedTextColor.RED));
                    return;
                }

                Player online = parsedUuid != null ? Bukkit.getPlayer(parsedUuid) : Bukkit.getPlayerExact(targetName);
                if (online != null) {
                    String appealLink = plugin.getConfig().getString("appeal-link", "");
                    online.kick(BanScreen.build(entry, appealLink));
                }

                String durationText = finalDuration > 0
                        ? "for " + TimeUtil.formatRemaining(finalDuration)
                        : "permanently";
                sender.sendMessage(Component.text(
                        "Banned " + finalResolvedName + " " + durationText + " (" + finalReason + ")"
                                + (finalSilent ? " [silent]" : ""),
                        NamedTextColor.GREEN));

                if (!alts.isEmpty()) {
                    String names = alts.stream().map(AltAccount::playerName).distinct()
                            .reduce((a, b) -> a + ", " + b).orElse("");
                    sender.sendMessage(Component.text("⚠ Possible alts (same IP): ", NamedTextColor.GOLD)
                            .append(Component.text(names, NamedTextColor.WHITE)));
                }

                if (!finalSilent && plugin.getConfig().getBoolean("broadcast-on-ban", true)) {
                    Bukkit.broadcast(Component.text("⚠ ", NamedTextColor.RED)
                            .append(Component.text(finalResolvedName, NamedTextColor.WHITE))
                            .append(Component.text(" was banned for ", NamedTextColor.GRAY))
                            .append(Component.text(finalReason, NamedTextColor.RED)));
                }
            });
        });

        return true;
    }
}
