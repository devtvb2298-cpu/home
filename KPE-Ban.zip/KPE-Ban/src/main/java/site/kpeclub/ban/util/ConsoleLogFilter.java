package site.kpeclub.ban.util;

import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.filter.AbstractFilter;
import org.apache.logging.log4j.message.Message;

/**
 * Denies any log event whose formatted message contains a marker string,
 * leaving everything else untouched. Used to keep specific lines (like the
 * multi-line ban kick screen) out of the console log without silencing
 * unrelated messages.
 */
public class ConsoleLogFilter extends AbstractFilter {

    private final String marker;

    public ConsoleLogFilter(String marker) {
        this.marker = marker;
    }

    @Override
    public Result filter(LogEvent event) {
        Message message = event.getMessage();
        if (message == null) return Result.NEUTRAL;
        String formatted = message.getFormattedMessage();
        return (formatted != null && formatted.contains(marker)) ? Result.DENY : Result.NEUTRAL;
    }
}
