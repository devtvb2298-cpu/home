package site.kpeclub.ban.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import site.kpeclub.ban.BanEntry;
import site.kpeclub.ban.BanManager;
import site.kpeclub.ban.util.Completions;
import site.kpeclub.ban.util.TimeUtil;
import site.kpeclub.ban.util.UuidUtil;

import java.util.List;
import java.util.UUID;

public class BanInfoCommand implements CommandExecutor, TabCompleter {

    private final BanManager banManager;

    public BanInfoCommand(BanManager banManager) {
        this.banManager = banManager;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Completions.knownNames(banManager, args[0]);
        }
        return List.of();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(Component.text("Usage: /baninfo <player|uuid>", NamedTextColor.RED));
            return true;
        }

        String targetName = args[0];
        UUID parsedUuid = UuidUtil.parse(targetName);

        BanEntry ban = parsedUuid != null
                ? banManager.getActiveBan(parsedUuid.toString())
                : banManager.getActiveBanByName(targetName);

        if (ban == null) {
            sender.sendMessage(Component.text(targetName + " is not banned.", NamedTextColor.GRAY));
            return true;
        }

        sender.sendMessage(Component.text("Ban #" + ban.getId() + " — " + ban.getPlayerName(), NamedTextColor.GOLD));
        sender.sendMessage(Component.text("Reason: " + ban.getReason(), NamedTextColor.GRAY));
        sender.sendMessage(Component.text("Banned by: " + ban.getBannedBy(), NamedTextColor.GRAY));
        if (ban.isPermanent()) {
            sender.sendMessage(Component.text("Expires: never", NamedTextColor.GRAY));
        } else {
            long remaining = ban.getExpiresAt() - System.currentTimeMillis();
            sender.sendMessage(Component.text("Expires in: " + TimeUtil.formatRemaining(remaining), NamedTextColor.GRAY));
        }
        return true;
    }
}
