package site.kpeclub.ban.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import site.kpeclub.ban.BanManager;
import site.kpeclub.ban.util.Completions;
import site.kpeclub.ban.util.IpUtil;

import java.util.List;

public class UnbanIpCommand implements CommandExecutor, TabCompleter {

    private final BanManager banManager;

    public UnbanIpCommand(BanManager banManager) {
        this.banManager = banManager;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Completions.bannedIps(banManager, args[0]);
        }
        return List.of();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 1 || !IpUtil.isIpAddress(args[0])) {
            sender.sendMessage(Component.text("Usage: /unbanip <ip>", NamedTextColor.RED));
            return true;
        }

        String ip = args[0];
        boolean removed = banManager.unbanIp(ip);

        if (removed) {
            sender.sendMessage(Component.text("Unbanned IP " + ip + ".", NamedTextColor.GREEN));
        } else {
            sender.sendMessage(Component.text(ip + " is not banned.", NamedTextColor.GRAY));
        }
        return true;
    }
}
