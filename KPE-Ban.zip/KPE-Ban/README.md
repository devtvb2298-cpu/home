# KPE-Ban

Paper plugin for `site.kpeclub`. Ban system with a DonutSMP-style kick screen
and SQLite storage.

## Build

```
mvn clean package
```

The jar comes out at `target/KPE-Ban.jar`. Drop it in your server's `plugins/`
folder and restart.

## Commands

- `/ban <player|uuid> [duration] [reason]`
  - First argument can be a player name **or** a raw UUID (dashed or undashed) —
    handy for banning someone pre-emptively from a UUID you already have (from
    a report, a log, etc.) before they've ever joined.
  - No duration → permanent ban. Default reason is "Cheating" (set in
    `config.yml`) if you leave it out.
  - Duration formats: `30s`, `10m`, `6h`, `7d`, `2w`, or `perm`.
  - This is the "cooldown ban": with a duration, the player is locked out
    until it runs out, and the ban screen shows a live countdown. Rejoining
    after it expires works normally — no manual unban needed.
  - Example: `/ban Steve7d hacking` bans Steve for 7 days.
  - Example: `/ban Steve` bans Steve permanently for "Cheating".
  - Example: `/ban 069a79f4-44e9-4726-a5be-fca90e38aaf5 perm exploiting` bans
    by raw UUID.
- `/unban <player|uuid>` — lifts an active ban early, by name or uuid.
- `/baninfo <player|uuid>` — shows reason, staff, and time left.
- `/banlist` — lists every active ban.
- `/banhistory <player>` — every past ban for a player, not just the current
  one: reason, staff, date, and status (`active`, `expired`, or `lifted`).
- `/banip <player|ip> [duration] [reason]` — bans a raw IP, or a player's most
  recently known IP. Blocks **every** account on that IP, not just one name —
  kicks anyone currently online from it too. Accepts the same duration formats
  as `/ban`. Never broadcast to chat (see below).
- `/unbanip <ip>` — lifts an IP ban.
- `/altcheck <player>` — lists other accounts that have connected from the
  same IP as this player.

Add `-s` or `--silent` anywhere in a `/ban` command to skip the public chat
broadcast (the target still sees the ban screen, and it's still stored and
listed normally) — e.g. `/ban Steve 7d hacking -s`.

## Ban screen

Shown on the kick screen and stored per-ban: reason, staff name, a ban ID,
the date, and either "permanent" or a countdown + expiry date. Also
broadcasts a short chat message server-wide when someone is banned
(toggle with `broadcast-on-ban` in `config.yml`, or skip it for one ban
with the `-s` flag above).

## IP bans & alt detection

Every login records the player's IP (`track-ips` in `config.yml`, on by
default), which powers three things:

- **`/banip`** — ban an IP directly, catching every account that connects
  from it, not just the one name you banned.
- **`/altcheck <player>`** — see what other accounts share an IP with them.
- **Auto-alert on `/ban`** — after a normal `/ban`, if the banned player
  shares an IP with any other known account, you get a one-line heads-up:
  `⚠ Possible alts (same IP): Name1, Name2`. Toggle with `show-alts-on-ban`.

IP bans are checked on login regardless of whether `track-ips` is on —
that setting only controls whether *new* IP data gets recorded, so turning
it off doesn't disable IP bans you've already placed.

IP addresses are never included in the public chat broadcast, even with
`broadcast-on-ban` on — only the staff member who ran `/banip` sees it
confirmed, to avoid posting player IPs in chat.

## Auto-ban from GrimAC / Vulcan

KPE-Ban doesn't hook into GrimAC's or Vulcan's Java code directly — their internal
APIs change often enough that a direct integration breaks on updates. Instead it
uses the console-command punishment system both already have built in, which is
far more stable.

**How it works:** you configure GrimAC (or Vulcan) to run this plugin's bridge
command once a check crosses **their** violation threshold:

```
kpebanauto <player> <check>
```

KPE-Ban then looks up `<check>` in **its own** `punishments.yml` and applies the
matching ban (duration + reason) through the normal ban system — same kick
screen, same storage, same broadcast as `/ban`.

### GrimAC setup (confirmed working syntax)

Add a category to GrimAC's `plugins/Grim/punishments.yml` (not this plugin's):

```yaml
Punishments:
  KPEBanCombat:
    remove-violations-after: 300
    checks:
      - "Hitbox"
      - "Reach"
    commands:
      - "15:15 kpebanauto %player% %check_name%"
```

`15:15` = fire once the check hits 15 non-expired violations, then again every
15 after that. GrimAC substitutes `%player%` and `%check_name%` itself.

### Vulcan setup

Vulcan attaches punishment commands **per individual check** (e.g. under
`checks.combat.<check-name>` in its config), each with its own `max-violations`
and a `commands` list — similar to the `ban: commands:` block already in a
default Vulcan config. The exact check names/paths vary by Vulcan version, so
the safest way is Vulcan's own in-game flow (`/vulcan gui`, or the "add
punishment command" prompt) rather than hand-editing the YAML. Set the
punishment command for your Reach/Hitbox-equivalent checks to:

```
kpebanauto %player% Reach
```

(hardcode the check name here — Vulcan doesn't expose a `%check%` placeholder
in that list, but since the command is already attached to a specific check,
you know it in advance.) Run `/vulcan checks` on your server to confirm the
exact check names first.

### punishments.yml (this plugin's, in `plugins/KPE-Ban/`)

```yaml
enabled: true   # master switch — false stops all auto-bans without touching GrimAC/Vulcan

rules:
  Hitbox:
    enabled: true
    duration: "perm"
    reason: "Combat hacks (Hitbox)"
  Reach:
    enabled: true
    duration: "perm"
    reason: "Combat hacks (Reach)"

default:
  enabled: true
  duration: "perm"
  reason: "Cheating (auto-detected)"
```

Two levels of on/off:
- `enabled` at the top — turns the whole auto-punish feature off, useful while
  you're still tuning GrimAC/Vulcan thresholds.
- `enabled` inside a single rule — turns off just that check (e.g. disable
  auto-ban for `Reach` while keeping `Hitbox` on) without deleting it.

Matching is case-insensitive and "contains" — a rule for `Hitbox` also matches
`HitboxA`, `HitboxB`, etc. `default` applies if `kpebanauto` fires for a check
with no matching rule; remove that section if you'd rather those do nothing.
Duration accepts the same formats as `/ban` (`30s`, `7d`, `perm`, ...).

Edit `punishments.yml` and run `/kpebanreload` to apply changes without a
restart — it also tells you whether auto-punish is currently enabled.

## Console log

By default, the multi-line ban screen no longer gets dumped into console
when a banned player is kicked (`hide-ban-console-log` in `config.yml`,
default `true`). This only removes that one message — other kicks and
disconnects still log as normal.

The server also prints `UUID of player X is Y` on every login, unrelated
to banning. It can be hidden too (`hide-uuid-resolve-log`), but it's off
by default since it affects *all* logins, not just banned ones.

## Notes

- Data is stored in `plugins/KPE-Ban/bans.db` (SQLite), so bans survive
  restarts.
- Built against Paper 1.20.4 API — bump the `paper-api` version in `pom.xml`
  if your server runs a different version.
- Uses offline-player UUID lookup, so it works the same whether your server
  is cracked or premium — same as your AuthMe setup.
